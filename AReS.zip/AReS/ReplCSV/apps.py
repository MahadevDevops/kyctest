from django.apps import AppConfig


class ReplcsvConfig(AppConfig):
    name = 'ReplCSV'
